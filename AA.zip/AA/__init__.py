"""AA package root."""
