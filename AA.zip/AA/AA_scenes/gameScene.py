from __future__ import annotations
from AA.AA_scenes import sceneClass
from AA.AA_utils import fontManager, inputManager, pygameText, musicManager, settings
from AA.AA_game import musicTrack, player, gameStates
from enum import Enum, auto
import pygame, os, math


class GameScene(sceneClass.Scene):

    def __init__(self, mainApp: pygame.Surface,
                 inputManager: inputManager.InputManager,
                 musicManager: musicManager.MusicManager,
                 track: musicTrack.GameTracks, players: tuple[player.Player,
                                                              player.Player]):
        self._players = players
        self._bgImage = pygame.transform.scale(
            pygame.image.load(
                os.path.join(settings.PARENT_PATH, "AA_images/dojo.jpg")),
            (1100, 600))

        self._chosenTrack = musicTrack.TrackBeatMap(track)
        self._currentTrackSection = 0

        self._fadeOutStarted = False

        self._state = gameStates.GameState.INITIAL_DELAY

        super().__init__(mainApp, inputManager, musicManager)

    def initScene(self):
        self._state = gameStates.GameState.INITIAL_DELAY
        for player in self._players:
            player.loadSection(self._chosenTrack.getSection(0))
        super().initScene()

    def loopScene(self, events: list[pygame.event.Event]):
        currentMusicElapsed = self._musicManager.getMusicElapsedSeconds(
        ) if self._musicManager.isMusicRunning() else -math.inf
        self._mainApp.fill((0, 0, 0))
        self._mainApp.blit(
            self._bgImage,
            self._bgImage.get_rect(center=self._mainApp.get_rect().center))

        currentText: list[pygameText.PygameText] = []

        if self._state == gameStates.GameState.INITIAL_DELAY:
            if self._stateTimer.elapsed() >= settings.GAME_START_DELAY:
                self._stateTimer.restart()
                self._currentTrackSection = 0
                self._musicManager.prepareSection(0, 3)
                for player in self._players:
                    player.loadSection(self._chosenTrack.getSection(0))
                self._state = gameStates.GameState.START_COUNTDOWN

        elif self._state == gameStates.GameState.START_COUNTDOWN:
            if self._stateTimer.elapsed() >= 3:
                self._musicManager.play(self._chosenTrack.audioFile, 0)
                self._fadeOutStarted = False
                self._state = gameStates.GameState.PLAY_SECTION
            else:
                txt = "3"
                if self._stateTimer.elapsed() >= 1:
                    txt = "2"
                if self._stateTimer.elapsed() >= 2:
                    txt = "1"
                txt = fontManager.upheaval(txt, 250, (255, 255, 255))

                currentText.append(
                    pygameText.PygameText(
                        txt,
                        txt.get_rect(
                            center=(self._mainApp.get_rect().centerx,
                                    self._mainApp.get_rect().centery))))

        elif self._state == gameStates.GameState.PLAY_SECTION:

            if not self._fadeOutStarted and (
                    currentMusicElapsed >= (self._chosenTrack.getSection(
                        self._currentTrackSection).musicEnd -
                                            settings.SONG_FADE_TIME_S)):
                self._fadeOutStarted = True
                self._musicManager.fadeout(
                    int(settings.SONG_FADE_TIME_S * 1000))

            if currentMusicElapsed >= self._chosenTrack.getSection(
                    self._currentTrackSection).musicEnd:
                self._musicManager.stop()
                self._fadeOutStarted = False
                self._state = gameStates.GameState.WAIT_FOR_ATTACK

        for player in self._players:
            player.update(currentMusicElapsed, self._state, self._inputManager)

        for txt in currentText:
            self._mainApp.blit(txt.text, txt.position)

        return super().loopScene(events)

    def getTransition(self):
        return super().getTransition()
