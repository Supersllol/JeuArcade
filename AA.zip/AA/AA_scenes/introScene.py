from __future__ import annotations

# class IntroScene(sceneClass.Scene):

#     def __init__(self, mainApp: pygame.Surface,
#                  inputManager: inputManager.InputManager):
#         super().__init__(mainApp, inputManager)

#     def initScene(self):
#         super().initScene()

#     def loopScene(self, events: list[pygame.event.Event]):
#         self._mainApp.fill((255, 255, 255))

#         # if joysticks[0].get_button(1):
#         #     self.finished = True
#         return super().loopScene(events)

#     def getTransition(self):
#         return homeScene.HomeScene(self._mainApp, self._inputManager)
