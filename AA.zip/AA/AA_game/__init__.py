"""Core game package."""
